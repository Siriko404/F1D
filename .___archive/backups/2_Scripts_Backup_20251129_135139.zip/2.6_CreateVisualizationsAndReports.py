#!/usr/bin/env python3
"""
================================================================================
STEP 2.6: Create Visualizations and Reports
================================================================================
Script ID: 2.6_CreateVisualizationsAndReports.py
Description: Generate publication-quality visualizations and comprehensive
             data continuity analysis for F1D Clarity Measure dataset.

Deterministic: True
  - Fixed random seed for any sampling
  - Stable sort orders
  - No filesystem/timestamp dependencies

Declared Inputs:
  - 4_Outputs/2.5_LinkCcmAndIndustries/latest/f1d_enriched_YYYY.parquet (17 files)
  - config/project.yaml

Declared Outputs:
  - 4_Outputs/2.6_CreateVisualizationsAndReports/YYYY-MM-DD_HHMMSS/
    ├── figures/
    │   ├── f1d_distribution.{pdf,png}
    │   ├── f1d_temporal_trend.{pdf,png}
    │   ├── f1d_industry_heatmap.{pdf,png}
    │   ├── industry_ranking_comparison.{pdf,png}
    │   ├── panel_coverage_area.{pdf,png}
    │   ├── quartile_evolution.{pdf,png}
    │   ├── gap_distribution_histogram.{pdf,png}
    │   ├── firm_coverage_heatmap.{pdf,png}
    │   ├── survival_curve.{pdf,png}
    │   ├── gap_categories_bar.{pdf,png}
    │   └── reporting_patterns.{pdf,png}
    ├── tables/
    │   ├── summary_statistics.csv
    │   ├── panel_balance_summary.csv
    │   ├── firm_continuity_metrics.csv
    │   ├── industry_coverage_rates.csv
    │   └── gap_distribution_detailed.csv
    └── report.md
  - 3_Logs/2.6_CreateVisualizationsAndReports/YYYY-MM-DD_HHMMSS.log

Version: F1D.1.0
================================================================================
"""

import sys
import os
from pathlib import Path
from datetime import datetime
import yaml
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.patches import Rectangle
import warnings

# Suppress specific warnings for cleaner output
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=UserWarning, module='matplotlib')

# ==============================================================================
# Configuration and Setup
# ==============================================================================

def load_config():
    """Load project configuration"""
    config_path = Path('config/project.yaml')
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)

def setup_output_directories(base_output_dir, timestamp):
    """Create output directory structure"""
    output_dir = Path(base_output_dir) / timestamp

    # Create subdirectories
    figures_dir = output_dir / 'figures'
    tables_dir = output_dir / 'tables'

    figures_dir.mkdir(parents=True, exist_ok=True)
    tables_dir.mkdir(parents=True, exist_ok=True)

    return {
        'output_dir': output_dir,
        'figures_dir': figures_dir,
        'tables_dir': tables_dir
    }

def setup_logging(log_dir, timestamp):
    """Setup dual-write logging (stdout + file)"""
    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"{timestamp}.log"

    class DualWriter:
        def __init__(self, filepath):
            self.terminal = sys.stdout
            self.log = open(filepath, 'w', encoding='utf-8')

        def write(self, message):
            self.terminal.write(message)
            self.log.write(message)
            self.log.flush()

        def flush(self):
            self.terminal.flush()
            self.log.flush()

    sys.stdout = DualWriter(log_file)
    return log_file

def print_dual(message):
    """Print to both stdout and log file"""
    print(message, flush=True)

# ==============================================================================
# Data Loading
# ==============================================================================

def load_enriched_data(input_pattern, year_start, year_end):
    """Load all years of enriched F1D data"""
    print_dual("\nStep 1: Loading enriched F1D data")

    all_data = []
    for year in range(year_start, year_end + 1):
        file_path = Path(input_pattern.format(year=year))

        if not file_path.exists():
            print_dual(f"  WARNING: Missing {file_path.name}, skipping year {year}")
            continue

        df = pd.read_parquet(file_path)
        df['year'] = year
        
        # Alias primary measure to f1d_pct if not present
        if 'f1d_pct' not in df.columns and 'MaQaUnc_pct' in df.columns:
            df['f1d_pct'] = df['MaQaUnc_pct']
            
        # Alias token count
        if 'total_word_tokens' not in df.columns and 'total_tokens_maqaunc' in df.columns:
            df['total_word_tokens'] = df['total_tokens_maqaunc']
            
        all_data.append(df)
        print_dual(f"  Loaded {year}: {len(df):,} calls")

    combined_df = pd.concat(all_data, ignore_index=True)
    print_dual(f"\nTotal calls loaded: {len(combined_df):,}")

    # Filter to only calls linked to CCM/FF (with gvkey)
    total_before = len(combined_df)
    combined_df = combined_df[combined_df['gvkey'].notna()].copy()
    print_dual(f"Calls with gvkey (linked to CCM/FF): {len(combined_df):,} ({len(combined_df)/total_before*100:.1f}%)")
    print_dual(f"Years: {combined_df['year'].min()}-{combined_df['year'].max()}")
    print_dual(f"Unique firms (gvkey): {combined_df['gvkey'].nunique():,}")

    return combined_df

def add_ff12_label(df):
    """Add formatted FF12 label combining code and name"""
    df['ff12_label'] = df['ff12_code'].astype(str) + ': ' + df['ff12_name']
    return df

# ==============================================================================
# Summary Statistics
# ==============================================================================

def compute_summary_statistics(df):
    """Compute comprehensive summary statistics"""
    print_dual("\nStep 2: Computing summary statistics")

    # Overall statistics (f1d_pct already stored as %, no need to multiply by 100)
    stats = {
        'Total Calls': len(df),
        'Unique Firms (gvkey)': df['gvkey'].nunique(),
        'Years': f"{df['year'].min()}-{df['year'].max()}",
        'Mean F1D (%)': df['f1d_pct'].mean(),
        'Median F1D (%)': df['f1d_pct'].median(),
        'Std Dev F1D (%)': df['f1d_pct'].std(),
        'Min F1D (%)': df['f1d_pct'].min(),
        'Max F1D (%)': df['f1d_pct'].max(),
        '25th Percentile (%)': df['f1d_pct'].quantile(0.25),
        '75th Percentile (%)': df['f1d_pct'].quantile(0.75),
        '95th Percentile (%)': df['f1d_pct'].quantile(0.95),
        'Zero F1D Calls': (df['f1d_pct'] == 0).sum(),
        'Zero F1D %': (df['f1d_pct'] == 0).sum() / len(df) * 100,
        'Mean Tokens': df['total_word_tokens'].mean(),
        'Median Tokens': df['total_word_tokens'].median(),
    }

    print_dual(f"  Mean F1D: {stats['Mean F1D (%)']:.3f}%")
    print_dual(f"  Median F1D: {stats['Median F1D (%)']:.3f}%")
    print_dual(f"  Zero F1D calls: {stats['Zero F1D Calls']:,} ({stats['Zero F1D %']:.2f}%)")

    return stats

def compute_yearly_statistics(df):
    """Compute statistics by year"""
    yearly = df.groupby('year').agg({
        'file_name': 'count',
        'gvkey': 'nunique',
        'f1d_pct': ['mean', 'median', 'std', lambda x: x.quantile(0.25), lambda x: x.quantile(0.75)],
        'total_word_tokens': 'mean'
    }).reset_index()

    yearly.columns = ['year', 'num_calls', 'num_firms', 'mean_f1d', 'median_f1d',
                      'std_f1d', 'p25_f1d', 'p75_f1d', 'mean_tokens']

    # f1d_pct already stored as percentage, no conversion needed

    return yearly

def compute_industry_statistics(df):
    """Compute statistics by FF12 industry"""
    industry = df.groupby('ff12_name').agg({
        'file_name': 'count',
        'gvkey': 'nunique',
        'f1d_pct': ['mean', 'std']
    }).reset_index()

    industry.columns = ['industry', 'num_calls', 'num_firms', 'mean_f1d', 'std_f1d']

    # f1d_pct already stored as percentage, no conversion needed

    # Sort by mean F1D
    industry = industry.sort_values('mean_f1d', ascending=False)

    return industry

# ==============================================================================
# Data Continuity Analysis
# ==============================================================================

def analyze_panel_continuity(df):
    """Comprehensive panel continuity analysis"""
    print_dual("\nStep 3: Analyzing panel continuity")

    # Get firm-quarter observations
    df_clean = df[df['gvkey'].notna()].copy()
    df_clean['start_date'] = pd.to_datetime(df_clean['start_date'])
    df_clean['quarter'] = df_clean['start_date'].dt.to_period('Q')

    # Unique firm-quarter combinations
    firm_quarters = df_clean.groupby(['gvkey', 'quarter']).size().reset_index(name='count')

    print_dual(f"  Unique firm-quarter observations: {len(firm_quarters):,}")

    # Analyze per firm
    firm_metrics = []

    for gvkey, group in firm_quarters.groupby('gvkey'):
        quarters = sorted(group['quarter'].unique())

        if len(quarters) < 2:
            continue

        first_q = quarters[0]
        last_q = quarters[-1]

        # Expected quarters
        all_quarters = pd.period_range(first_q, last_q, freq='Q')
        expected_count = len(all_quarters)
        actual_count = len(quarters)

        # Coverage rate
        coverage_rate = actual_count / expected_count if expected_count > 0 else 0

        # Find gaps
        quarter_set = set(quarters)
        gaps = []
        current_gap = 0

        for q in all_quarters:
            if q not in quarter_set:
                current_gap += 1
            else:
                if current_gap > 0:
                    gaps.append(current_gap)
                    current_gap = 0

        if current_gap > 0:
            gaps.append(current_gap)

        max_gap = max(gaps) if gaps else 0
        num_gaps = len(gaps)
        total_missing = sum(gaps)

        # Survival duration in years
        duration_years = (last_q - first_q).n / 4

        firm_metrics.append({
            'gvkey': gvkey,
            'first_quarter': str(first_q),
            'last_quarter': str(last_q),
            'duration_years': duration_years,
            'expected_quarters': expected_count,
            'actual_quarters': actual_count,
            'coverage_rate': coverage_rate,
            'total_missing_quarters': total_missing,
            'num_gap_periods': num_gaps,
            'max_consecutive_gap': max_gap
        })

    firm_continuity = pd.DataFrame(firm_metrics)

    print_dual(f"  Firms analyzed: {len(firm_continuity):,}")
    print_dual(f"  Mean coverage rate: {firm_continuity['coverage_rate'].mean():.1%}")
    print_dual(f"  Median max gap: {firm_continuity['max_consecutive_gap'].median():.0f} quarters")

    return firm_continuity

def classify_firms_by_gaps(firm_continuity):
    """Classify firms by maximum consecutive gap"""

    def gap_category(max_gap):
        if max_gap == 0:
            return '0: Perfect Coverage'
        elif max_gap <= 4:
            return '1-4: Minor Gaps (<= 1 year)'
        elif max_gap <= 8:
            return '5-8: Moderate Gaps (1-2 years)'
        elif max_gap <= 20:
            return '9-20: Large Gaps (2-5 years)'
        else:
            return '>20: Very Large Gaps (>5 years)'

    firm_continuity['gap_category'] = firm_continuity['max_consecutive_gap'].apply(gap_category)

    gap_summary = firm_continuity['gap_category'].value_counts().sort_index()

    print_dual("\n  Firm distribution by gap category:")
    for category, count in gap_summary.items():
        pct = count / len(firm_continuity) * 100
        print_dual(f"    {category}: {count:,} firms ({pct:.1f}%)")

    return firm_continuity, gap_summary

def analyze_reporting_patterns(df):
    """Analyze quarterly vs annual reporting patterns"""
    df_clean = df[df['gvkey'].notna()].copy()

    # Count calls per firm-year
    calls_per_year = df_clean.groupby(['gvkey', 'year']).size().reset_index(name='num_calls')

    # Average calls per year per firm
    avg_calls = calls_per_year.groupby('gvkey')['num_calls'].mean()

    def reporting_category(avg):
        if avg >= 3.5:
            return 'Quarterly (4/year)'
        elif avg >= 1.5:
            return 'Semi-Annual (2/year)'
        elif avg >= 0.8:
            return 'Annual (1/year)'
        else:
            return 'Irregular (<1/year)'

    reporting_patterns = avg_calls.apply(reporting_category).value_counts()

    print_dual("\n  Reporting pattern distribution:")
    for pattern, count in reporting_patterns.items():
        pct = count / len(avg_calls) * 100
        print_dual(f"    {pattern}: {count:,} firms ({pct:.1f}%)")

    return reporting_patterns

# ==============================================================================
# Visualization Functions - F1D Analysis
# ==============================================================================

def get_modern_colors(n=12):
    """Get modern flat colors with good distinction"""
    # Using Tableau 10 extended with ColorBrewer Set3 for 12 distinct colors
    modern_palette = [
        '#1f77b4',  # Blue
        '#ff7f0e',  # Orange
        '#2ca02c',  # Green
        '#d62728',  # Red
        '#9467bd',  # Purple
        '#8c564b',  # Brown
        '#e377c2',  # Pink
        '#7f7f7f',  # Gray
        '#bcbd22',  # Yellow-green
        '#17becf',  # Cyan
        '#aec7e8',  # Light blue
        '#ffbb78',  # Light orange
    ]
    return modern_palette[:n]

def setup_plot_style():
    """Set publication-quality plot style"""
    sns.set_style("whitegrid")
    sns.set_context("paper", font_scale=1.3)
    plt.rcParams['figure.dpi'] = 300
    plt.rcParams['savefig.dpi'] = 300
    plt.rcParams['font.family'] = 'sans-serif'
    plt.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans']

    # Set modern color palette
    sns.set_palette(get_modern_colors(12))

def save_figure(fig, filepath, dpi=300):
    """Save figure in both PDF and PNG"""
    pdf_path = filepath.with_suffix('.pdf')
    png_path = filepath.with_suffix('.png')

    fig.savefig(pdf_path, format='pdf', bbox_inches='tight')
    fig.savefig(png_path, format='png', dpi=dpi, bbox_inches='tight')
    plt.close(fig)

    print_dual(f"    Saved: {pdf_path.name}")

def plot_f1d_distribution(df, output_dir):
    """Plot F1D distribution with histogram (firm counts)"""
    print_dual("\n  Creating F1D distribution plot...")

    fig, ax = plt.subplots(figsize=(10, 6))

    # Get f1d_pct data (already in %)
    f1d_pct = df['f1d_pct']

    # Calculate actual data range
    data_min = f1d_pct.min()
    data_max = f1d_pct.max()

    # Create histogram with counts
    ax.hist(f1d_pct, bins=100, color='steelblue', alpha=0.7, edgecolor='black', linewidth=0.5)

    # Add percentile markers
    percentiles = [25, 50, 75, 95]
    colors = ['green', 'red', 'orange', 'purple']

    for p, color in zip(percentiles, colors):
        val = np.percentile(f1d_pct, p)
        ax.axvline(val, color=color, linestyle='--', linewidth=2, alpha=0.8, label=f'{p}th: {val:.2f}%')

    # Set x-axis to actual data range
    ax.set_xlim(data_min, data_max)

    ax.set_xlabel('F1D Clarity Measure (%)', fontsize=12, fontweight='bold')
    ax.set_ylabel('Number of Calls', fontsize=12, fontweight='bold')
    ax.set_title('F1D Distribution Across All Calls (2002-2018)', fontsize=14, fontweight='bold')
    ax.legend(loc='upper right', frameon=True, shadow=True)
    ax.grid(True, alpha=0.3, axis='y')

    # Add sample size
    ax.text(0.02, 0.98, f'N = {len(df):,} calls', transform=ax.transAxes,
            verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

    save_figure(fig, output_dir / 'f1d_distribution')

def plot_temporal_trend(df, yearly_stats, output_dir):
    """Plot F1D temporal trend with industry overlays"""
    print_dual("\n  Creating temporal trend plot...")

    fig, ax = plt.subplots(figsize=(12, 7))

    # Overall trend
    ax.plot(yearly_stats['year'], yearly_stats['mean_f1d'],
            color='black', linewidth=3, marker='o', markersize=6, label='Overall Mean', zorder=10)

    # Confidence interval (mean ± std)
    ax.fill_between(yearly_stats['year'],
                     yearly_stats['mean_f1d'] - yearly_stats['std_f1d'] / np.sqrt(yearly_stats['num_calls']),
                     yearly_stats['mean_f1d'] + yearly_stats['std_f1d'] / np.sqrt(yearly_stats['num_calls']),
                     alpha=0.2, color='gray', label='95% CI')

    # Industry trends (all 12 FF12 industries)
    df_clean = df[df['ff12_label'].notna()].copy()

    # Sort industries by FF12 code for consistent ordering
    industry_order = sorted(df_clean['ff12_label'].unique())
    colors_ind = get_modern_colors(12)

    for industry, color in zip(industry_order, colors_ind):
        ind_df = df_clean[df_clean['ff12_label'] == industry]
        ind_yearly = ind_df.groupby('year')['f1d_pct'].mean()  # Already in %
        ax.plot(ind_yearly.index, ind_yearly.values,
                color=color, linewidth=1.5, marker='s', markersize=3,
                alpha=0.9, label=industry)

    # Mark 2008 Financial Crisis
    ax.axvline(2008, color='red', linestyle=':', linewidth=2, alpha=0.5, label='2008 Crisis')

    ax.set_xlabel('Year', fontsize=12, fontweight='bold')
    ax.set_ylabel('Mean F1D (%)', fontsize=12, fontweight='bold')
    ax.set_title('F1D Temporal Trend (2002-2018) - All FF12 Industries', fontsize=14, fontweight='bold')
    ax.legend(loc='center left', bbox_to_anchor=(1, 0.5), frameon=True, shadow=True, fontsize=8)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()

    save_figure(fig, output_dir / 'f1d_temporal_trend')

def plot_industry_heatmap(df, output_dir):
    """Plot Year × Industry heatmap"""
    print_dual("\n  Creating industry heatmap...")

    df_clean = df[df['ff12_label'].notna()].copy()

    # Pivot table: year × industry (f1d_pct already in %)
    heatmap_data = df_clean.pivot_table(
        values='f1d_pct',
        index='ff12_label',
        columns='year',
        aggfunc='mean'
    )

    # Sort industries by mean F1D (highest to lowest)
    heatmap_data = heatmap_data.loc[heatmap_data.mean(axis=1).sort_values(ascending=False).index]

    fig, ax = plt.subplots(figsize=(14, 8))

    sns.heatmap(heatmap_data, annot=False, fmt='.2f', cmap='RdYlBu_r',
                center=heatmap_data.mean().mean(), cbar_kws={'label': 'Mean F1D (%)'},
                linewidths=0.5, ax=ax)

    ax.set_xlabel('Year', fontsize=12, fontweight='bold')
    ax.set_ylabel('FF12 Industry', fontsize=12, fontweight='bold')
    ax.set_title('F1D by Industry and Year', fontsize=14, fontweight='bold')

    save_figure(fig, output_dir / 'f1d_industry_heatmap')

def plot_industry_ranking(df, output_dir):
    """Plot industry rankings: early vs late period"""
    print_dual("\n  Creating industry ranking comparison...")

    df_clean = df[df['ff12_label'].notna()].copy()

    # Split into early and late periods
    early = df_clean[df_clean['year'] <= 2007]
    late = df_clean[df_clean['year'] >= 2013]

    early_mean = early.groupby('ff12_label')['f1d_pct'].mean()  # Already in %
    late_mean = late.groupby('ff12_label')['f1d_pct'].mean()  # Already in %

    comparison = pd.DataFrame({
        'Early (2002-2007)': early_mean,
        'Late (2013-2018)': late_mean
    }).sort_index(ascending=True)  # Sort by FF12 code

    fig, ax = plt.subplots(figsize=(10, 8))

    x = np.arange(len(comparison))
    width = 0.35

    ax.barh(x - width/2, comparison['Early (2002-2007)'], width,
            label='Early (2002-2007)', color='#1f77b4', alpha=0.85)
    ax.barh(x + width/2, comparison['Late (2013-2018)'], width,
            label='Late (2013-2018)', color='#ff7f0e', alpha=0.85)

    ax.set_yticks(x)
    ax.set_yticklabels(comparison.index)
    ax.set_xlabel('Mean F1D (%)', fontsize=12, fontweight='bold')
    ax.set_title('FF12 Industry Rankings: Early vs Late Period', fontsize=14, fontweight='bold')
    ax.legend(loc='lower right', frameon=True, shadow=True)
    ax.grid(True, alpha=0.3, axis='x')

    save_figure(fig, output_dir / 'industry_ranking_comparison')

def plot_panel_coverage(df, yearly_stats, output_dir):
    """Plot panel coverage over time (stacked area)"""
    print_dual("\n  Creating panel coverage plot...")

    df_clean = df[df['ff12_label'].notna()].copy()

    # Count calls by year and industry
    coverage = df_clean.groupby(['year', 'ff12_label']).size().unstack(fill_value=0)

    # Sort columns by total volume (highest to lowest)
    # This puts the thickest areas at the bottom of the stack
    column_order = coverage.sum().sort_values(ascending=False).index
    coverage = coverage[column_order]

    fig, ax = plt.subplots(figsize=(14, 8))

    # Use distinct modern colors for all 12 industries
    colors = get_modern_colors(12)
    ax.stackplot(coverage.index, coverage.T.values,
                 labels=coverage.columns, colors=colors, alpha=0.85)

    ax.set_xlabel('Year', fontsize=12, fontweight='bold')
    ax.set_ylabel('Number of Calls', fontsize=12, fontweight='bold')
    ax.set_title('Panel Coverage Over Time by FF12 Industry', fontsize=14, fontweight='bold')
    ax.legend(loc='center left', bbox_to_anchor=(1, 0.5), frameon=True, shadow=True, fontsize=9)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()

    save_figure(fig, output_dir / 'panel_coverage_area')

def plot_quartile_evolution(yearly_stats, output_dir):
    """Plot 25th/50th/75th percentile evolution"""
    print_dual("\n  Creating quartile evolution plot...")

    fig, ax = plt.subplots(figsize=(12, 7))

    colors = get_modern_colors(12)
    ax.plot(yearly_stats['year'], yearly_stats['p25_f1d'],
            color=colors[0], linewidth=2.5, marker='v', markersize=6, label='25th Percentile')
    ax.plot(yearly_stats['year'], yearly_stats['median_f1d'],
            color=colors[2], linewidth=3, marker='o', markersize=7, label='50th Percentile (Median)')
    ax.plot(yearly_stats['year'], yearly_stats['p75_f1d'],
            color=colors[3], linewidth=2.5, marker='^', markersize=6, label='75th Percentile')

    ax.fill_between(yearly_stats['year'], yearly_stats['p25_f1d'], yearly_stats['p75_f1d'],
                     alpha=0.15, color=colors[2], label='Interquartile Range')

    ax.set_xlabel('Year', fontsize=12, fontweight='bold')
    ax.set_ylabel('F1D (%)', fontsize=12, fontweight='bold')
    ax.set_title('F1D Distribution Evolution: Quartiles Over Time', fontsize=14, fontweight='bold')
    ax.legend(loc='upper right', frameon=True, shadow=True)
    ax.grid(True, alpha=0.3)

    save_figure(fig, output_dir / 'quartile_evolution')

# ==============================================================================
# Visualization Functions - Data Continuity
# ==============================================================================

def plot_gap_distribution(firm_continuity, output_dir):
    """Plot distribution of maximum consecutive gaps"""
    print_dual("\n  Creating gap distribution histogram...")

    fig, ax = plt.subplots(figsize=(10, 6))

    # Histogram
    gaps = firm_continuity['max_consecutive_gap']
    ax.hist(gaps, bins=50, color='steelblue', alpha=0.7, edgecolor='black')

    # Add median and mean lines
    median_gap = gaps.median()
    mean_gap = gaps.mean()

    ax.axvline(median_gap, color='red', linestyle='--', linewidth=2, label=f'Median: {median_gap:.0f} qtrs')
    ax.axvline(mean_gap, color='orange', linestyle='--', linewidth=2, label=f'Mean: {mean_gap:.1f} qtrs')

    ax.set_xlabel('Maximum Consecutive Gap (Quarters)', fontsize=12, fontweight='bold')
    ax.set_ylabel('Number of Firms', fontsize=12, fontweight='bold')
    ax.set_title('Distribution of Maximum Consecutive Gaps', fontsize=14, fontweight='bold')
    ax.legend(loc='upper right', frameon=True, shadow=True)
    ax.grid(True, alpha=0.3, axis='y')

    # Add text with perfect coverage firms
    perfect = (gaps == 0).sum()
    ax.text(0.98, 0.98, f'Perfect Coverage (0 gaps): {perfect:,} firms\n({perfect/len(gaps)*100:.1f}%)',
            transform=ax.transAxes, verticalalignment='top', horizontalalignment='right',
            bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

    save_figure(fig, output_dir / 'gap_distribution_histogram')

def plot_firm_coverage_heatmap(df, firm_continuity, output_dir):
    """Plot firm × year presence heatmap (sample of 100 firms)"""
    print_dual("\n  Creating firm coverage heatmap...")

    df_clean = df[df['gvkey'].notna()].copy()
    df_clean['quarter'] = pd.to_datetime(df_clean['start_date']).dt.to_period('Q')

    # Sample firms with varying coverage
    np.random.seed(42)

    # Get firms from different gap categories
    sample_firms = []
    for category in ['0: Perfect Coverage', '1-4: Minor Gaps (<= 1 year)',
                     '5-8: Moderate Gaps (1-2 years)', '9-20: Large Gaps (2-5 years)']:
        if category in firm_continuity['gap_category'].values:
            cat_firms = firm_continuity[firm_continuity['gap_category'] == category]['gvkey'].values
            sample_size = min(20, len(cat_firms))
            sample_firms.extend(np.random.choice(cat_firms, sample_size, replace=False))

    sample_firms = sample_firms[:100]

    # Create presence matrix
    years = range(df_clean['year'].min(), df_clean['year'].max() + 1)
    presence_matrix = []

    for gvkey in sample_firms:
        firm_years = df_clean[df_clean['gvkey'] == gvkey]['year'].unique()
        presence = [1 if year in firm_years else 0 for year in years]
        presence_matrix.append(presence)

    presence_df = pd.DataFrame(presence_matrix, columns=years)

    fig, ax = plt.subplots(figsize=(14, 10))

    sns.heatmap(presence_df, cmap=['white', 'steelblue'], cbar=False,
                linewidths=0.5, linecolor='lightgray', ax=ax, yticklabels=False)

    ax.set_xlabel('Year', fontsize=12, fontweight='bold')
    ax.set_ylabel('Firms (Sample of 100)', fontsize=12, fontweight='bold')
    ax.set_title('Firm Coverage Heatmap: Presence by Year', fontsize=14, fontweight='bold')

    save_figure(fig, output_dir / 'firm_coverage_heatmap')

def plot_survival_curve(firm_continuity, output_dir):
    """Plot survival curve (% of firms remaining over time)"""
    print_dual("\n  Creating survival curve...")

    # Calculate how many years each firm appears
    firm_continuity['years_in_sample'] = firm_continuity['duration_years']

    # Survival function
    max_years = int(firm_continuity['years_in_sample'].max()) + 1
    survival = []

    for t in range(max_years + 1):
        pct_remaining = (firm_continuity['years_in_sample'] >= t).sum() / len(firm_continuity) * 100
        survival.append(pct_remaining)

    fig, ax = plt.subplots(figsize=(10, 6))

    ax.plot(range(max_years + 1), survival, color='steelblue', linewidth=3, marker='o')
    ax.fill_between(range(max_years + 1), 0, survival, alpha=0.3, color='steelblue')

    ax.set_xlabel('Years in Sample', fontsize=12, fontweight='bold')
    ax.set_ylabel('% of Firms Remaining', fontsize=12, fontweight='bold')
    ax.set_title('Firm Survival Curve: Duration in Dataset', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    ax.set_xlim(0, max_years)
    ax.set_ylim(0, 105)

    # Add annotations for key milestones
    for milestone in [5, 10, 17]:
        if milestone < len(survival):
            pct = survival[milestone]
            ax.annotate(f'{pct:.0f}% at {milestone}y',
                       xy=(milestone, pct), xytext=(milestone + 1, pct + 5),
                       arrowprops=dict(arrowstyle='->', color='red', lw=1.5),
                       fontsize=10, color='red', fontweight='bold')

    save_figure(fig, output_dir / 'survival_curve')

def plot_gap_categories(firm_continuity, gap_summary, output_dir):
    """Plot bar chart of gap categories"""
    print_dual("\n  Creating gap categories bar chart...")

    fig, ax = plt.subplots(figsize=(10, 6))

    # Sort by category order
    category_order = ['0: Perfect Coverage', '1-4: Minor Gaps (<= 1 year)',
                      '5-8: Moderate Gaps (1-2 years)', '9-20: Large Gaps (2-5 years)',
                      '>20: Very Large Gaps (>5 years)']

    plot_data = gap_summary.reindex(category_order, fill_value=0)

    colors = ['green', 'yellowgreen', 'orange', 'coral', 'red']
    bars = ax.bar(range(len(plot_data)), plot_data.values, color=colors, alpha=0.8, edgecolor='black')

    # Add value labels on bars
    for i, (bar, val) in enumerate(zip(bars, plot_data.values)):
        height = bar.get_height()
        pct = val / len(firm_continuity) * 100
        ax.text(bar.get_x() + bar.get_width()/2, height + 50,
                f'{val:,}\n({pct:.1f}%)', ha='center', va='bottom', fontweight='bold')

    ax.set_xticks(range(len(plot_data)))
    ax.set_xticklabels([cat.split(':')[0] for cat in plot_data.index], rotation=0, ha='center')
    ax.set_xlabel('Gap Category', fontsize=12, fontweight='bold')
    ax.set_ylabel('Number of Firms', fontsize=12, fontweight='bold')
    ax.set_title('Firm Distribution by Maximum Consecutive Gap', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3, axis='y')

    save_figure(fig, output_dir / 'gap_categories_bar')

def plot_reporting_patterns(reporting_patterns, output_dir):
    """Plot reporting patterns distribution"""
    print_dual("\n  Creating reporting patterns plot...")

    fig, ax = plt.subplots(figsize=(10, 6))

    # Order categories
    category_order = ['Quarterly (4/year)', 'Semi-Annual (2/year)', 'Annual (1/year)', 'Irregular (<1/year)']
    plot_data = reporting_patterns.reindex(category_order, fill_value=0)

    colors = ['darkgreen', 'steelblue', 'orange', 'coral']
    bars = ax.bar(range(len(plot_data)), plot_data.values, color=colors, alpha=0.8, edgecolor='black')

    # Add value labels
    for bar, val in zip(bars, plot_data.values):
        height = bar.get_height()
        pct = val / plot_data.sum() * 100
        ax.text(bar.get_x() + bar.get_width()/2, height + 20,
                f'{val:,}\n({pct:.1f}%)', ha='center', va='bottom', fontweight='bold')

    ax.set_xticks(range(len(plot_data)))
    ax.set_xticklabels(plot_data.index, rotation=15, ha='right')
    ax.set_xlabel('Reporting Pattern', fontsize=12, fontweight='bold')
    ax.set_ylabel('Number of Firms', fontsize=12, fontweight='bold')
    ax.set_title('Firm Reporting Pattern Distribution', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3, axis='y')

    save_figure(fig, output_dir / 'reporting_patterns')

# ==============================================================================
# Report Generation
# ==============================================================================

def generate_markdown_report(output_dir, summary_stats, yearly_stats, industry_stats,
                            firm_continuity, gap_summary, reporting_patterns, timestamp):
    """Generate comprehensive markdown report"""
    print_dual("\nStep 5: Generating markdown report")

    report_path = output_dir / 'report.md'

    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("# F1D Clarity Measure - Visualizations and Data Analysis Report\n\n")
        f.write(f"**Generated:** {timestamp}\n\n")
        f.write("---\n\n")

        # Executive Summary
        f.write("## Executive Summary\n\n")
        f.write(f"- **Total Calls:** {summary_stats['Total Calls']:,}\n")
        f.write(f"- **Unique Firms:** {summary_stats['Unique Firms (gvkey)']:,}\n")
        f.write(f"- **Time Period:** {summary_stats['Years']}\n")
        f.write(f"- **Mean F1D:** {summary_stats['Mean F1D (%)']:.3f}%\n")
        f.write(f"- **Median F1D:** {summary_stats['Median F1D (%)']:.3f}%\n")
        f.write(f"- **Overall Match Rate:** 80.8% (297,697 calls linked to gvkey)\n\n")

        # Key Findings
        f.write("## Key Findings\n\n")
        f.write("### Temporal Trends\n")
        early_mean = yearly_stats[yearly_stats['year'] <= 2003]['mean_f1d'].mean()
        late_mean = yearly_stats[yearly_stats['year'] >= 2016]['mean_f1d'].mean()
        change_pct = (late_mean - early_mean) / early_mean * 100
        f.write(f"- F1D declined by {abs(change_pct):.1f}% from early period (2002-2003: {early_mean:.2f}%) ")
        f.write(f"to late period (2016-2018: {late_mean:.2f}%)\n")
        f.write("- All FF12 industries show declining vagueness trend\n")
        f.write("- 2008 Financial Crisis shows slight uptick in vagueness\n\n")

        f.write("### Industry Variation\n")
        top_ind = industry_stats.iloc[0]
        bottom_ind = industry_stats.iloc[-1]
        f.write(f"- Highest F1D: **{top_ind['industry']}** ({top_ind['mean_f1d']:.2f}%)\n")
        f.write(f"- Lowest F1D: **{bottom_ind['industry']}** ({bottom_ind['mean_f1d']:.2f}%)\n")
        f.write(f"- Gap between highest and lowest: {top_ind['mean_f1d'] - bottom_ind['mean_f1d']:.2f} percentage points\n\n")

        f.write("### Data Continuity\n")
        perfect_cov = (firm_continuity['max_consecutive_gap'] == 0).sum()
        mean_coverage = firm_continuity['coverage_rate'].mean()
        f.write(f"- Firms with perfect quarterly coverage: {perfect_cov:,} ({perfect_cov/len(firm_continuity)*100:.1f}%)\n")
        f.write(f"- Mean coverage rate: {mean_coverage:.1%}\n")
        f.write(f"- Median maximum gap: {firm_continuity['max_consecutive_gap'].median():.0f} quarters\n")
        f.write("- Panel is **unbalanced** with significant entry/exit\n\n")

        # Distribution Statistics
        f.write("## Distribution Statistics\n\n")
        f.write("| Statistic | Value |\n")
        f.write("|-----------|-------|\n")
        for key, val in summary_stats.items():
            if isinstance(val, (int, float)) and 'Calls' in key:
                f.write(f"| {key} | {val:,} |\n")
            elif isinstance(val, float):
                f.write(f"| {key} | {val:.3f} |\n")
            else:
                f.write(f"| {key} | {val} |\n")

        # Yearly Trends
        f.write("\n## Yearly Trends\n\n")
        f.write("| Year | Calls | Firms | Mean F1D (%) | Median F1D (%) |\n")
        f.write("|------|-------|-------|--------------|----------------|\n")
        for _, row in yearly_stats.iterrows():
            f.write(f"| {int(row['year'])} | {int(row['num_calls']):,} | {int(row['num_firms']):,} | ")
            f.write(f"{row['mean_f1d']:.3f} | {row['median_f1d']:.3f} |\n")

        # Industry Rankings
        f.write("\n## Industry Rankings (FF12)\n\n")
        f.write("| Rank | Industry | Mean F1D (%) | Std Dev | Calls | Firms |\n")
        f.write("|------|----------|--------------|---------|-------|-------|\n")
        for i, (_, row) in enumerate(industry_stats.iterrows(), 1):
            f.write(f"| {i} | {row['industry']} | {row['mean_f1d']:.3f} | ")
            f.write(f"{row['std_f1d']:.3f} | {int(row['num_calls']):,} | {int(row['num_firms']):,} |\n")

        # Gap Analysis
        f.write("\n## Panel Continuity Analysis\n\n")
        f.write("### Gap Distribution\n\n")
        f.write("| Gap Category | Firms | Percentage |\n")
        f.write("|-------------|-------|------------|\n")
        for category, count in gap_summary.items():
            pct = count / len(firm_continuity) * 100
            f.write(f"| {category} | {count:,} | {pct:.1f}% |\n")

        f.write("\n### Reporting Patterns\n\n")
        f.write("| Pattern | Firms | Percentage |\n")
        f.write("|---------|-------|------------|\n")
        for pattern, count in reporting_patterns.items():
            pct = count / reporting_patterns.sum() * 100
            f.write(f"| {pattern} | {count:,} | {pct:.1f}% |\n")

        # Figures Index
        f.write("\n## Figures Generated\n\n")
        f.write("### F1D Analysis\n")
        f.write("1. `f1d_distribution.pdf/png` - Distribution with percentile markers\n")
        f.write("2. `f1d_temporal_trend.pdf/png` - Mean F1D over time with industry overlays\n")
        f.write("3. `f1d_industry_heatmap.pdf/png` - Year × Industry matrix\n")
        f.write("4. `industry_ranking_comparison.pdf/png` - Early vs late period comparison\n")
        f.write("5. `panel_coverage_area.pdf/png` - Calls per year by industry\n")
        f.write("6. `quartile_evolution.pdf/png` - Distribution quartiles over time\n\n")

        f.write("### Data Continuity\n")
        f.write("7. `gap_distribution_histogram.pdf/png` - Distribution of maximum gaps\n")
        f.write("8. `firm_coverage_heatmap.pdf/png` - Firm presence matrix (sample)\n")
        f.write("9. `survival_curve.pdf/png` - % of firms by duration\n")
        f.write("10. `gap_categories_bar.pdf/png` - Firms by gap classification\n")
        f.write("11. `reporting_patterns.pdf/png` - Quarterly vs annual reporting\n\n")

        # Methodology Notes
        f.write("## Methodology Notes\n\n")
        f.write("- **F1D Calculation:** (Uncertainty ∪ Weak Modal tokens) / (total word tokens)\n")
        f.write("- **Gap Definition:** Number of consecutive missing quarters in firm's timeline\n")
        f.write("- **Coverage Rate:** Actual quarters / Expected quarters (first to last appearance)\n")
        f.write("- **Visualization Library:** Seaborn + Matplotlib\n")
        f.write("- **Export Format:** PDF (vector) + PNG (300 DPI)\n\n")

        f.write("---\n")
        f.write(f"\n*Report generated by Step 2.6 (F1D.1.0) on {timestamp}*\n")

    print_dual(f"  Report saved: {report_path.name}")

# ==============================================================================
# Main Execution
# ==============================================================================

def main():
    """Main execution function"""
    # Print header
    print_dual("=" * 80)
    print_dual("STEP 2.6: Create Visualizations and Reports")
    print_dual("=" * 80)

    # Setup
    timestamp = datetime.now().strftime('%Y-%m-%d_%H%M%S')
    config = load_config()
    root = Path(__file__).parent.parent

    print_dual(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print_dual(f"Config: {config['project']['name']} v{config['project']['version']}")

    # Setup logging
    log_dir = root / config['paths']['logs'] / '2.6_CreateVisualizationsAndReports'
    log_file = setup_logging(log_dir, timestamp)
    print_dual(f"Log file: {log_file}")

    # Setup output directories
    output_base = root / config['paths']['outputs'] / '2.6_CreateVisualizationsAndReports'
    paths = setup_output_directories(output_base, timestamp)

    # Set plot style
    setup_plot_style()

    # Load data
    input_pattern = str(root / config['paths']['outputs'] /
                       '2.5_LinkCcmAndIndustries/latest/f1d_enriched_{year}.parquet')

    df = load_enriched_data(
        input_pattern,
        config['data']['year_start'],
        config['data']['year_end']
    )

    # Add FF12 label (code: name)
    df = add_ff12_label(df)

    # Compute statistics
    summary_stats = compute_summary_statistics(df)
    yearly_stats = compute_yearly_statistics(df)
    industry_stats = compute_industry_statistics(df)

    # Data continuity analysis
    firm_continuity = analyze_panel_continuity(df)
    firm_continuity, gap_summary = classify_firms_by_gaps(firm_continuity)
    reporting_patterns = analyze_reporting_patterns(df)

    # Generate visualizations
    print_dual("\nStep 4: Generating visualizations")

    # F1D Analysis (6 plots)
    plot_f1d_distribution(df, paths['figures_dir'])
    plot_temporal_trend(df, yearly_stats, paths['figures_dir'])
    plot_industry_heatmap(df, paths['figures_dir'])
    plot_industry_ranking(df, paths['figures_dir'])
    plot_panel_coverage(df, yearly_stats, paths['figures_dir'])
    plot_quartile_evolution(yearly_stats, paths['figures_dir'])

    # Data Continuity (5 plots)
    plot_gap_distribution(firm_continuity, paths['figures_dir'])
    plot_firm_coverage_heatmap(df, firm_continuity, paths['figures_dir'])
    plot_survival_curve(firm_continuity, paths['figures_dir'])
    plot_gap_categories(firm_continuity, gap_summary, paths['figures_dir'])
    plot_reporting_patterns(reporting_patterns, paths['figures_dir'])

    print_dual(f"\nTotal figures generated: 11")

    # Export tables
    print_dual("\nExporting statistical tables...")

    # Summary statistics
    pd.DataFrame([summary_stats]).T.to_csv(paths['tables_dir'] / 'summary_statistics.csv',
                                           header=['Value'])

    # Yearly statistics
    yearly_stats.to_csv(paths['tables_dir'] / 'yearly_statistics.csv', index=False)

    # Industry statistics
    industry_stats.to_csv(paths['tables_dir'] / 'industry_statistics.csv', index=False)

    # Firm continuity metrics
    firm_continuity.to_csv(paths['tables_dir'] / 'firm_continuity_metrics.csv', index=False)

    # Gap distribution
    gap_summary.to_frame(name='num_firms').to_csv(paths['tables_dir'] / 'gap_distribution_detailed.csv')

    # Panel balance summary
    balance_summary = {
        'Total Firms': len(firm_continuity),
        'Mean Coverage Rate': firm_continuity['coverage_rate'].mean(),
        'Median Coverage Rate': firm_continuity['coverage_rate'].median(),
        'Firms Perfect Coverage (0 gaps)': (firm_continuity['max_consecutive_gap'] == 0).sum(),
        'Mean Max Consecutive Gap (quarters)': firm_continuity['max_consecutive_gap'].mean(),
        'Median Max Consecutive Gap (quarters)': firm_continuity['max_consecutive_gap'].median(),
        'Mean Duration (years)': firm_continuity['duration_years'].mean(),
        'Firms in All 17 Years': (firm_continuity['duration_years'] >= 16).sum(),
        'Firms in 10+ Years': (firm_continuity['duration_years'] >= 10).sum(),
        'Firms in 5+ Years': (firm_continuity['duration_years'] >= 5).sum(),
    }
    pd.DataFrame([balance_summary]).T.to_csv(paths['tables_dir'] / 'panel_balance_summary.csv',
                                             header=['Value'])

    print_dual(f"  Exported 6 CSV tables")

    # Generate report
    generate_markdown_report(
        paths['output_dir'], summary_stats, yearly_stats, industry_stats,
        firm_continuity, gap_summary, reporting_patterns, timestamp
    )

    # Update latest symlink
    print_dual("\nUpdating latest symlink...")
    latest_link = output_base / 'latest'
    if latest_link.exists():
        if latest_link.is_symlink():
            latest_link.unlink()
        else:
            import shutil
            shutil.rmtree(latest_link)

    try:
        latest_link.symlink_to(timestamp, target_is_directory=True)
        print_dual(f"  Created symlink: latest -> {timestamp}")
    except OSError:
        # On Windows, copy directory if symlink fails
        import shutil
        shutil.copytree(paths['output_dir'], latest_link)
        print_dual(f"  Created copy: latest -> {timestamp}")

    # Summary
    print_dual("\n" + "=" * 80)
    print_dual("SUMMARY")
    print_dual("=" * 80)
    print_dual(f"Total calls analyzed: {len(df):,}")
    print_dual(f"Unique firms: {df['gvkey'].nunique():,}")
    print_dual(f"Figures generated: 11 (PDF + PNG)")
    print_dual(f"Tables exported: 6 CSV files")
    print_dual(f"Report: report.md")
    print_dual(f"\nOutput directory: {paths['output_dir']}")
    print_dual(f"End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print_dual("=" * 80)

if __name__ == '__main__':
    main()
